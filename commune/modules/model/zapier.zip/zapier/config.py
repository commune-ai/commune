# Bot Command Prefix
pre = 'm!'
# Discord Channel IDs
mail_channel_id = 965512433458356226 
send_channel_id = 965512433458356226
# host:port
imap_host = 'imap.gmail.com'
imap_port = 993
smtp_host = 'smtp.gmail.com:465'
# AUTH for both imap & smtp
userEmail = 'jackveustar1228@gmail.com'
password = 'phuwgsiwxajsbocz'
#  
from_mail = 'jackveustar1228@gmail.com'
# Discord Bot Token
token = 'MTE3NzYwNDI2NTM3MjU0OTEzMA.GSHst6.8BZT41kUZ4x_r7n_ZhrtB1l2HRwb8wk6TQPV9M'